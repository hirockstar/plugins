---
name: kd-power-commerce
description: Use when the user asks to search KD Power products, check compatibility, create or review an order, retrieve an invoice, or check account balance and payment history.
---

# KD Power commerce workflow

Use the KD Power MCP tools for all KD Power data and actions. Do not browse the KD Power website, scrape pages, call undocumented HTTP endpoints, or infer account data from conversation context.

## Product requests

- Use `search_products` for product discovery.
- Put a phone model or device in `compatibilityQuery` when the user asks whether an item fits or is supported.
- Respect the returned product and variant IDs.
- Present price, stock, compatibility, warranty, and variant information only from the tool result.
- If there are multiple plausible products, ask the user to choose before creating an order.

## Orders

- Use `create_order` only after the user has clearly requested an order.
- Confirm the selected products, variants, quantities, and notes before calling the write tool when the request is ambiguous.
- Never claim that payment was completed; the tool creates a pending order.
- Tell the user that checkout and payment continue on `https://kdpower.in` when they want to complete payment.
- Treat server-returned totals, stock, ownership, and permissions as authoritative.

## Order status and invoices

- Use `get_order_status` with the exact KD Power order number.
- Use `get_invoice` for invoice details and the returned view or download links.
- Do not expose another user's order or invoice details.

## Account information

- Use `whoami` when the signed-in account or role needs to be confirmed.
- Use `get_balance` for the current balance.
- Use `list_balance_history` for bounded transaction history, applying the user's requested filters.

## Errors and permissions

- Explain authentication or shopkeeper-permission errors clearly and ask the user to connect the correct KD Power account.
- Do not retry a write automatically after an ambiguous timeout unless the user confirms whether the order was created.
- Keep responses concise and summarize the authoritative result returned by the tool.
